package jp.ac.ait.k00000;

public class Enemy extends CharacterBase{
    public Enemy(String name, int hp, int atk, int def, int agi) {
        super(name, hp, atk, def, agi);
    }
}
