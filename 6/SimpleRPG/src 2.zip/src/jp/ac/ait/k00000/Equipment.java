package jp.ac.ait.k00000;

public class Equipment {

    private String name;

    //初期値セット
    public Equipment(String name){
    }

    //名前を「装備」で初期化
    public Equipment(){
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
}
