package jp.ac.ait.k21099;

import java.util.List;

public interface IKadai07_3 {
    List<String> getUniqueList(List<String> targetList);
}
