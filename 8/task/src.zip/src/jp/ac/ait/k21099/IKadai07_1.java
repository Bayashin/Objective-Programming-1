package jp.ac.ait.k21099;

import java.util.List;

public interface IKadai07_1 {
    List<Integer> get(int max_value);
}
