package jp.ac.ait.k21099;

import java.util.List;

public interface IKadai07_2 {
    List<String> getConverted(List<Integer> targetList);
}
